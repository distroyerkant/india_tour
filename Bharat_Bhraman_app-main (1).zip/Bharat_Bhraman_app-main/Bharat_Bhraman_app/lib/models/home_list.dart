import "package:flutter/material.dart";

class Home_item {
  final String imageurl;
  final String titile;
  final Function ontap;
  Home_item(
      {@required this.imageurl, @required this.titile, @required this.ontap});
}
