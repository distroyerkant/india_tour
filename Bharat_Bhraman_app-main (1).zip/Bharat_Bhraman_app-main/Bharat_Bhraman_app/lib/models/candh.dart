import 'package:flutter/material.dart';

class Cultureandheritage {
  final String imageurl;
  final String title;
  Cultureandheritage({this.imageurl, this.title});
}
