import 'package:flutter/material.dart';

class Generalinformation {
  final String imageurl;
  final String title;
  final String description;
  final String date;
  final String name;
  final String url;
  Generalinformation(
      {this.imageurl,
      this.title,
      this.description,
      this.date,
      this.name,
      this.url});
}
