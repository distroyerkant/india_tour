class Nie {
  final String imageurl;
  final String title;
  final String backgroudimageurl;
  final String description;
  Nie({this.imageurl, this.title, this.backgroudimageurl, this.description});
}
