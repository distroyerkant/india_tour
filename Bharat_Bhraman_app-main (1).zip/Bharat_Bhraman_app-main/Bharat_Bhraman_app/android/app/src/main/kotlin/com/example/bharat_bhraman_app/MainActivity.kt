package com.example.bharat_bhraman_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
