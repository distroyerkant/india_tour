# Bharat_Bhraman_app
 Beleow is the drive link of our main and admin section app and video demonstration of the project as well as the powerpoint presentation
 https://drive.google.com/drive/folders/1uKhfZABgNhixXqGHjIsR0o2U2u3ezF9j
 The Github Repo for our admin app is https://github.com/shivam9472/Bharat_bhraman_Adminside
 
